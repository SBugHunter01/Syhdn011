#!/bin/bash
echo   "L7 Setup"
read -sp "Press [ENTER] To Start."
sudo apt update -y && sudo apt upgrade -y
cd /media/
sudo apt install golang-go
sudo apt install gcc-go
sudo apt install nodejs npm unzip -y
sudo apt install apache2 php php-fpm php-ssh2 -y
sudo npm i gradient-string
sudo npm i cluster
sudo npm i crypto
sudo npm i http
sudo npm i http2
sudo npm i net
sudo npm i tls
sudo npm i url
sudo npm i fs
sudo npm i puppeteer-extra
sudo npm i puppeteer
sudo npm i puppeteer-extra-plugin-stealth
sudo npm i request
sudo npm i sync-request
sudo npm i fake-useragent
sudo npm i randomstring
sudo npm i events
sudo npm i cloudscraper
sudo npm i user-agents
sudo npm i random-ua
sudo npm i requests
sudo npm i https-proxy-agent
sudo npm i proxy-agent
sudo npm i crypto-random-string
sudo npm i events
sudo npm i fs
sudo npm i net
sudo npm i cloudscraper
sudo npm i request
sudo npm i hcaptcha-solver
sudo npm i randomstring
sudo npm i cloudflare-bypasser
ulimit -n 999999 